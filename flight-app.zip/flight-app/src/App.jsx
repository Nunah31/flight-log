import { useState, useEffect, useCallback } from "react";
import * as XLSX from "xlsx";

const SHEET_ID = "1Tb6gfUgZm3VdRN2L0ZlZd0zwhnxQDHX95khHC8sjXtE";
const DURATION_OPTIONS = [10, 20, 30, 40, 60];
const AIRPORTS = ["עין ורד", "נען", "עין יהב", "אחר - הזן ידנית"];

function formatDate(d) {
  if (!d) return "";
  const parts = d.split("-");
  return `${parts[2]}/${parts[1]}/${parts[0]}`;
}

function todayISO() {
  return new Date().toISOString().split("T")[0];
}

const emptyFlight = () => ({
  date: todayISO(),
  origin: "עין ורד",
  originCustom: "",
  departureTime: "",
  duration: "",
  durationCustom: "",
  flightType: "פרטית",
  notes: "",
});

async function sheetsRequest(body) {
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system: `You are a Google Sheets API assistant. The user will ask you to read or write data to a Google Sheet.
Always respond ONLY with valid JSON, no explanation, no markdown fences.
For read requests respond: {"rows": [[...], ...]} where each inner array is a row of cell values.
For write requests respond: {"ok": true}.
For errors respond: {"error": "description"}.`,
      messages: [{ role: "user", content: body }],
      mcp_servers: [{ type: "url", url: "https://drivemcp.googleapis.com/mcp/v1", name: "gdrive" }],
    }),
  });
  const data = await response.json();
  const text = data.content?.filter(b => b.type === "text").map(b => b.text).join("") || "{}";
  try { return JSON.parse(text.replace(/```json|```/g, "").trim()); }
  catch { return { error: "parse error: " + text }; }
}

async function loadFlightsFromSheet() {
  const result = await sheetsRequest(
    `Read all data from Google Sheet ID "${SHEET_ID}", sheet name "יומן טיסות". Return all rows including header row. If the sheet doesn't exist or is empty return {"rows":[]}.`
  );
  if (!result.rows || result.rows.length < 2) return [];
  const [header, ...rows] = result.rows;
  return rows.map(row => {
    const obj = {};
    header.forEach((h, i) => { obj[h] = row[i] || ""; });
    return obj;
  }).filter(r => r["תאריך"]);
}

async function appendFlightToSheet(record) {
  const row = [
    record["תאריך"], record["מקום המראה"],
    record["שעת המראה"], record["זמן טיסה"], record["סוג טיסה"], record["הערות"]
  ];
  return await sheetsRequest(
    `In Google Sheet ID "${SHEET_ID}", sheet "יומן טיסות":
1. If the sheet doesn't exist, create it with header row: תאריך, מקום המראה, שעת המראה, זמן טיסה, סוג טיסה, הערות
2. Append this row of data: ${JSON.stringify(row)}
Respond with {"ok": true} when done.`
  );
}

async function updateFlightInSheet(rowIndex, record) {
  const sheetRow = rowIndex + 2;
  const row = [
    record["תאריך"], record["מקום המראה"],
    record["שעת המראה"], record["זמן טיסה"], record["סוג טיסה"], record["הערות"]
  ];
  return await sheetsRequest(
    `In Google Sheet ID "${SHEET_ID}", sheet "יומן טיסות", update row number ${sheetRow} (1-based) with these values in columns A through F: ${JSON.stringify(row)}. Respond with {"ok": true}.`
  );
}

async function deleteFlightFromSheet(rowIndex) {
  const sheetRow = rowIndex + 2;
  return await sheetsRequest(
    `In Google Sheet ID "${SHEET_ID}", sheet "יומן טיסות", delete row number ${sheetRow} (1-based). Respond with {"ok": true}.`
  );
}

export default function App() {
  const [flights, setFlights] = useState([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState(emptyFlight());
  const [editIndex, setEditIndex] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [toast, setToast] = useState(null);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [sortField, setSortField] = useState("תאריך");
  const [sortDir, setSortDir] = useState("desc");

  const showToast = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  const loadFlights = useCallback(async () => {
    setLoading(true);
    try {
      const rows = await loadFlightsFromSheet();
      setFlights(rows);
    } catch {
      showToast("שגיאה בטעינת נתונים מהדרייב", "error");
    }
    setLoading(false);
  }, []);

  useEffect(() => { loadFlights(); }, [loadFlights]);

  function handleChange(field, value) {
    setForm(f => ({ ...f, [field]: value }));
  }

  function getOriginValue() {
    return form.origin === "אחר - הזן ידנית" ? form.originCustom : form.origin;
  }
  function getDurationValue() {
    return form.duration === "custom"
      ? (form.durationCustom ? `${form.durationCustom} דקות` : "")
      : (form.duration ? `${form.duration} דקות` : "");
  }

  function validateForm() {
    if (!form.date) return "יש להזין תאריך";
    if (!form.origin) return "יש לבחור מקום המראה";
    if (form.origin === "אחר - הזן ידנית" && !form.originCustom) return "יש להזין מקום המראה";
    if (!form.departureTime) return "יש להזין שעת המראה";
    if (!form.duration) return "יש לבחור זמן טיסה";
    if (form.duration === "custom" && !form.durationCustom) return "יש להזין זמן טיסה";
    return null;
  }

  async function handleSubmit() {
    const err = validateForm();
    if (err) { showToast(err, "error"); return; }

    const record = {
      "תאריך": form.date,
      "מקום המראה": getOriginValue(),
      "שעת המראה": form.departureTime,
      "זמן טיסה": getDurationValue(),
      "סוג טיסה": form.flightType,
      "הערות": form.notes,
    };

    setSaving(true);
    try {
      if (editIndex !== null) {
        const res = await updateFlightInSheet(editIndex, record);
        if (res.error) throw new Error(res.error);
        const updated = [...flights];
        updated[editIndex] = record;
        setFlights(updated);
        showToast("הטיסה עודכנה בהצלחה ✓");
        setEditIndex(null);
      } else {
        const res = await appendFlightToSheet(record);
        if (res.error) throw new Error(res.error);
        setFlights(fs => [...fs, record]);
        showToast("הטיסה נשמרה לדרייב ✓");
      }
      setForm(emptyFlight());
      setShowForm(false);
    } catch (e) {
      showToast("שגיאה בשמירה: " + e.message, "error");
    }
    setSaving(false);
  }

  function handleEdit(flight, index) {
    const isKnownOrigin = AIRPORTS.includes(flight["מקום המראה"]);
    const durationNum = parseInt(flight["זמן טיסה"]);
    const isKnownDur = DURATION_OPTIONS.includes(durationNum);
    setForm({
      date: flight["תאריך"],
      origin: isKnownOrigin ? flight["מקום המראה"] : "אחר - הזן ידנית",
      originCustom: isKnownOrigin ? "" : flight["מקום המראה"],
      departureTime: flight["שעת המראה"],
      duration: isKnownDur ? String(durationNum) : "custom",
      durationCustom: isKnownDur ? "" : String(durationNum),
      flightType: flight["סוג טיסה"] || "פרטית",
      notes: flight["הערות"] || "",
    });
    setEditIndex(index);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function handleDelete(index) {
    setSaving(true);
    try {
      const res = await deleteFlightFromSheet(index);
      if (res.error) throw new Error(res.error);
      setFlights(fs => fs.filter((_, i) => i !== index));
      showToast("הטיסה נמחקה");
    } catch {
      showToast("שגיאה במחיקה", "error");
    }
    setDeleteConfirm(null);
    setSaving(false);
  }

  function handleSort(field) {
    if (sortField === field) setSortDir(d => d === "asc" ? "desc" : "asc");
    else { setSortField(field); setSortDir("asc"); }
  }

  const sorted = [...flights].sort((a, b) => {
    let va = a[sortField] || "", vb = b[sortField] || "";
    if (sortField === "זמן טיסה") { va = parseInt(va) || 0; vb = parseInt(vb) || 0; }
    if (va < vb) return sortDir === "asc" ? -1 : 1;
    if (va > vb) return sortDir === "asc" ? 1 : -1;
    return 0;
  });

  function exportToExcel() {
    if (flights.length === 0) { showToast("אין טיסות לייצוא", "error"); return; }
    const data = sorted.map((f, i) => ({ "#": i + 1, ...f }));
    const ws = XLSX.utils.json_to_sheet(data);
    ws["!cols"] = [{ wch: 4 }, { wch: 12 }, { wch: 18 }, { wch: 12 }, { wch: 12 }, { wch: 14 }, { wch: 30 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "יומן טיסות");
    XLSX.writeFile(wb, `יומן_טיסות_${new Date().toLocaleDateString("he-IL").replace(/\//g, "-")}.xlsx`);
    showToast("הקובץ יוצא בהצלחה ✓");
  }

  const SortIcon = ({ field }) => {
    if (sortField !== field) return <span style={{ opacity: 0.3, fontSize: 10 }}>↕</span>;
    return <span style={{ fontSize: 10 }}>{sortDir === "asc" ? "↑" : "↓"}</span>;
  };

  return (
    <div dir="rtl" style={{
      minHeight: "100vh",
      background: "linear-gradient(135deg, #0a0e1a 0%, #0d1b2e 50%, #0a0e1a 100%)",
      fontFamily: "'Segoe UI', 'Arial Hebrew', Arial, sans-serif",
      color: "#e8f4ff", padding: "0 0 60px 0",
    }}>
      {/* Header */}
      <div style={{
        background: "linear-gradient(90deg, #0a1628 0%, #112244 50%, #0a1628 100%)",
        borderBottom: "1px solid rgba(100,180,255,0.15)",
        padding: "20px 24px", display: "flex", alignItems: "center",
        justifyContent: "space-between", flexWrap: "wrap", gap: 12,
        boxShadow: "0 4px 32px rgba(0,80,200,0.15)"
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{
            width: 46, height: 46, borderRadius: 12,
            background: "linear-gradient(135deg, #1a6aff, #0a3aaa)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 22, boxShadow: "0 4px 16px rgba(30,100,255,0.4)"
          }}>✈</div>
          <div>
            <div style={{ fontSize: 20, fontWeight: 700, color: "#fff" }}>יומן טיסות — אודי הברי</div>
            <div style={{ fontSize: 12, color: "#7ab8ff", marginTop: 2 }}>
              {loading ? "טוען..." : `${flights.length} טיסות מתועדות`}
            </div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <button onClick={loadFlights} disabled={loading} style={{
            background: "rgba(255,255,255,0.06)", color: "#7ab8ff",
            border: "1px solid rgba(100,160,255,0.2)", borderRadius: 9,
            padding: "8px 16px", cursor: "pointer", fontWeight: 600, fontSize: 13,
          }}>🔄 רענן</button>
          <button onClick={exportToExcel} style={{
            background: "linear-gradient(135deg, #1a7a3a, #0e5a28)",
            color: "#90ffb0", border: "1px solid rgba(100,255,150,0.25)",
            borderRadius: 9, padding: "8px 16px", cursor: "pointer", fontWeight: 600, fontSize: 13,
          }}>📊 ייצא לאקסל</button>
          <button onClick={() => { setShowForm(!showForm); setEditIndex(null); setForm(emptyFlight()); }} style={{
            background: showForm ? "rgba(255,80,80,0.15)" : "linear-gradient(135deg, #1a6aff, #0a3aaa)",
            color: showForm ? "#ff9090" : "#fff",
            border: showForm ? "1px solid rgba(255,100,100,0.3)" : "none",
            borderRadius: 9, padding: "8px 18px", cursor: "pointer", fontWeight: 700, fontSize: 14,
          }}>{showForm ? "✕ סגור" : "+ הוסף טיסה"}</button>
        </div>
      </div>

      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "0 16px" }}>

        {/* Form */}
        {showForm && (
          <div style={{
            background: "linear-gradient(135deg, #0e1e38, #111e35)",
            border: "1px solid rgba(100,160,255,0.2)", borderRadius: 16,
            padding: "24px", marginTop: 24, marginBottom: 8,
            boxShadow: "0 8px 40px rgba(0,40,120,0.3)",
          }}>
            <div style={{ fontSize: 15, fontWeight: 700, color: "#7ab8ff", marginBottom: 20 }}>
              {editIndex !== null ? "✏️ עריכת טיסה" : "✈ הוספת טיסה חדשה"}
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(190px, 1fr))", gap: 14 }}>

              <Field label="📅 תאריך">
                <input type="date" value={form.date} onChange={e => handleChange("date", e.target.value)} style={inputStyle} />
              </Field>

              <Field label="🕐 שעת המראה">
                <input type="time" value={form.departureTime} onChange={e => handleChange("departureTime", e.target.value)} style={inputStyle} />
              </Field>

              <Field label="🛫 מקום המראה">
                <select value={form.origin} onChange={e => handleChange("origin", e.target.value)} style={inputStyle}>
                  {AIRPORTS.map(a => <option key={a} value={a}>{a}</option>)}
                </select>
                {form.origin === "אחר - הזן ידנית" && (
                  <input type="text" placeholder="הזן מקום המראה" value={form.originCustom}
                    onChange={e => handleChange("originCustom", e.target.value)}
                    style={{ ...inputStyle, marginTop: 8 }} />
                )}
              </Field>

              <Field label="⏱ זמן טיסה">
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                  {DURATION_OPTIONS.map(d => (
                    <button key={d} onClick={() => handleChange("duration", String(d))} style={{
                      padding: "7px 11px", borderRadius: 8, border: "1px solid", cursor: "pointer",
                      fontWeight: 600, fontSize: 13, transition: "all 0.15s",
                      background: form.duration === String(d) ? "linear-gradient(135deg,#1a6aff,#0a3aaa)" : "rgba(255,255,255,0.05)",
                      borderColor: form.duration === String(d) ? "#1a6aff" : "rgba(255,255,255,0.15)",
                      color: form.duration === String(d) ? "#fff" : "#aac8f0",
                    }}>{d}′</button>
                  ))}
                  <button onClick={() => handleChange("duration", "custom")} style={{
                    padding: "7px 11px", borderRadius: 8, border: "1px solid", cursor: "pointer",
                    fontWeight: 600, fontSize: 13, transition: "all 0.15s",
                    background: form.duration === "custom" ? "linear-gradient(135deg,#8a4aff,#5a2aaa)" : "rgba(255,255,255,0.05)",
                    borderColor: form.duration === "custom" ? "#8a4aff" : "rgba(255,255,255,0.15)",
                    color: form.duration === "custom" ? "#fff" : "#aac8f0",
                  }}>ידני</button>
                </div>
                {form.duration === "custom" && (
                  <input type="number" min="1" max="600" placeholder="דקות" value={form.durationCustom}
                    onChange={e => handleChange("durationCustom", e.target.value)}
                    style={{ ...inputStyle, marginTop: 8, width: 90 }} />
                )}
              </Field>

              <Field label="✈ סוג טיסה">
                <div style={{ display: "flex", gap: 8 }}>
                  {["פרטית", "מסחרית", "אחרת"].map(t => (
                    <button key={t} onClick={() => handleChange("flightType", t)} style={{
                      padding: "7px 12px", borderRadius: 8, border: "1px solid", cursor: "pointer",
                      fontWeight: 600, fontSize: 13, transition: "all 0.15s",
                      background: form.flightType === t ? "linear-gradient(135deg,#ff8a1a,#cc5a00)" : "rgba(255,255,255,0.05)",
                      borderColor: form.flightType === t ? "#ff8a1a" : "rgba(255,255,255,0.15)",
                      color: form.flightType === t ? "#fff" : "#aac8f0",
                    }}>{t}</button>
                  ))}
                </div>
              </Field>

              <div style={{ gridColumn: "1 / -1" }}>
                <Field label="📝 הערות">
                  <textarea value={form.notes} onChange={e => handleChange("notes", e.target.value)}
                    placeholder="הערות נוספות..." rows={2}
                    style={{ ...inputStyle, resize: "vertical", minHeight: 52 }} />
                </Field>
              </div>
            </div>

            <div style={{ marginTop: 20, display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button onClick={() => { setShowForm(false); setEditIndex(null); setForm(emptyFlight()); }} style={{
                background: "transparent", color: "#7ab8ff",
                border: "1px solid rgba(100,160,255,0.3)", borderRadius: 9,
                padding: "10px 22px", cursor: "pointer", fontWeight: 600, fontSize: 14
              }}>ביטול</button>
              <button onClick={handleSubmit} disabled={saving} style={{
                background: saving ? "rgba(30,100,255,0.4)" : "linear-gradient(135deg,#1a6aff,#0a3aaa)",
                color: "#fff", border: "none", borderRadius: 9,
                padding: "10px 26px", cursor: saving ? "not-allowed" : "pointer",
                fontWeight: 700, fontSize: 15, boxShadow: "0 4px 20px rgba(30,100,255,0.4)",
              }}>
                {saving ? "⏳ שומר..." : (editIndex !== null ? "💾 עדכן טיסה" : "✅ שמור לדרייב")}
              </button>
            </div>
          </div>
        )}

        {/* Loading */}
        {loading && (
          <div style={{ textAlign: "center", padding: "60px 20px", color: "#4a7aaa" }}>
            <div style={{ fontSize: 36, marginBottom: 12, animation: "spin 1.5s linear infinite", display: "inline-block" }}>✈</div>
            <div>טוען נתונים מ-Google Drive...</div>
          </div>
        )}

        {/* Table */}
        {!loading && (
          <div style={{ marginTop: showForm ? 20 : 24 }}>
            {flights.length === 0 ? (
              <div style={{ textAlign: "center", padding: "80px 20px", color: "#4a7aaa", fontSize: 15 }}>
                <div style={{ fontSize: 52, marginBottom: 16, opacity: 0.3 }}>✈</div>
                <div>אין טיסות עדיין. הוסף את הטיסה הראשונה!</div>
              </div>
            ) : (
              <div style={{
                background: "rgba(10,20,40,0.6)", border: "1px solid rgba(100,160,255,0.15)",
                borderRadius: 16, overflow: "hidden", boxShadow: "0 4px 32px rgba(0,30,80,0.3)"
              }}>
                <div style={{ overflowX: "auto" }}>
                  <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
                    <thead>
                      <tr style={{ background: "rgba(20,50,100,0.5)", borderBottom: "1px solid rgba(100,160,255,0.2)" }}>
                        {[
                          { key: "תאריך", label: "📅 תאריך" },
                          { key: "מקום המראה", label: "🛫 המראה" },
                          { key: "שעת המראה", label: "🕐 שעה" },
                          { key: "זמן טיסה", label: "⏱ זמן" },
                          { key: "סוג טיסה", label: "✈ סוג" },
                          { key: "הערות", label: "📝 הערות" },
                        ].map(col => (
                          <th key={col.key} onClick={() => handleSort(col.key)} style={{
                            padding: "12px 14px", textAlign: "right", cursor: "pointer",
                            color: sortField === col.key ? "#7ab8ff" : "#5a88bb",
                            fontWeight: 700, fontSize: 13, whiteSpace: "nowrap", userSelect: "none",
                          }}>
                            {col.label} <SortIcon field={col.key} />
                          </th>
                        ))}
                        <th style={{ padding: "12px 14px", color: "#5a88bb", fontWeight: 700, fontSize: 13 }}>פעולות</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sorted.map((f, i) => {
                        const origIdx = flights.indexOf(f);
                        return (
                          <tr key={i} style={{
                            borderBottom: "1px solid rgba(100,160,255,0.08)",
                            background: i % 2 === 0 ? "transparent" : "rgba(20,40,80,0.2)",
                            transition: "background 0.15s",
                          }}
                            onMouseEnter={e => e.currentTarget.style.background = "rgba(30,80,180,0.18)"}
                            onMouseLeave={e => e.currentTarget.style.background = i % 2 === 0 ? "transparent" : "rgba(20,40,80,0.2)"}
                          >
                            <td style={tdStyle}>{formatDate(f["תאריך"])}</td>
                            <td style={tdStyle}><span style={{ color: "#90c8ff" }}>{f["מקום המראה"]}</span></td>
                            <td style={tdStyle}><span style={{ fontFamily: "monospace", color: "#aad4ff" }}>{f["שעת המראה"]}</span></td>
                            <td style={tdStyle}>
                              <span style={{
                                background: "rgba(30,100,255,0.2)", color: "#7ab8ff",
                                borderRadius: 6, padding: "2px 10px", fontSize: 13, fontWeight: 600
                              }}>{f["זמן טיסה"]}</span>
                            </td>
                            <td style={tdStyle}>
                              <span style={{
                                background: f["סוג טיסה"] === "פרטית" ? "rgba(255,140,30,0.18)" : "rgba(80,200,120,0.15)",
                                color: f["סוג טיסה"] === "פרטית" ? "#ffaa60" : "#60dd90",
                                borderRadius: 6, padding: "2px 10px", fontSize: 12, fontWeight: 600
                              }}>{f["סוג טיסה"]}</span>
                            </td>
                            <td style={{ ...tdStyle, maxWidth: 200, color: "#8aabcc", fontSize: 13 }}>
                              <span style={{ display: "block", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                                {f["הערות"] || "—"}
                              </span>
                            </td>
                            <td style={{ ...tdStyle, whiteSpace: "nowrap" }}>
                              <button onClick={() => handleEdit(f, origIdx)} style={{
                                background: "rgba(100,160,255,0.12)", color: "#7ab8ff",
                                border: "1px solid rgba(100,160,255,0.25)", borderRadius: 7,
                                padding: "5px 11px", cursor: "pointer", fontSize: 13, marginLeft: 6,
                              }}>✏️</button>
                              <button onClick={() => setDeleteConfirm(origIdx)} style={{
                                background: "rgba(255,80,80,0.1)", color: "#ff8080",
                                border: "1px solid rgba(255,100,100,0.2)", borderRadius: 7,
                                padding: "5px 11px", cursor: "pointer", fontSize: 13,
                              }}>🗑</button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
                <div style={{ padding: "10px 16px", borderTop: "1px solid rgba(100,160,255,0.1)", color: "#4a7aaa", fontSize: 12, textAlign: "left" }}>
                  סה"כ: {flights.length} טיסות
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Delete Confirm */}
      {deleteConfirm !== null && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100 }}
          onClick={() => setDeleteConfirm(null)}>
          <div onClick={e => e.stopPropagation()} style={{
            background: "#0e1e38", border: "1px solid rgba(255,80,80,0.3)",
            borderRadius: 16, padding: "28px 32px", maxWidth: 340, textAlign: "center",
            boxShadow: "0 20px 60px rgba(0,0,0,0.6)"
          }}>
            <div style={{ fontSize: 32, marginBottom: 12 }}>🗑</div>
            <div style={{ fontSize: 16, fontWeight: 600, marginBottom: 6 }}>מחיקת טיסה</div>
            <div style={{ color: "#7a9abb", marginBottom: 22, fontSize: 13 }}>הטיסה תימחק גם מה-Google Sheet</div>
            <div style={{ display: "flex", gap: 10, justifyContent: "center" }}>
              <button onClick={() => setDeleteConfirm(null)} style={{
                padding: "9px 20px", borderRadius: 9, cursor: "pointer",
                background: "transparent", color: "#7ab8ff",
                border: "1px solid rgba(100,160,255,0.3)", fontWeight: 600, fontSize: 14
              }}>ביטול</button>
              <button onClick={() => handleDelete(deleteConfirm)} disabled={saving} style={{
                padding: "9px 20px", borderRadius: 9, cursor: "pointer",
                background: "linear-gradient(135deg,#cc2222,#881111)",
                color: "#fff", border: "none", fontWeight: 700, fontSize: 14
              }}>{saving ? "מוחק..." : "מחק"}</button>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      {toast && (
        <div style={{
          position: "fixed", bottom: 28, left: "50%", transform: "translateX(-50%)",
          background: toast.type === "error" ? "linear-gradient(135deg,#cc2222,#881111)" : "linear-gradient(135deg,#1a7a3a,#0e5a28)",
          color: "#fff", borderRadius: 12, padding: "12px 28px",
          fontWeight: 600, fontSize: 15, zIndex: 200, boxShadow: "0 8px 32px rgba(0,0,0,0.4)",
          animation: "fadeInUp 0.3s ease", whiteSpace: "nowrap",
        }}>{toast.msg}</div>
      )}

      <style>{`
        @keyframes fadeInUp { from { opacity:0; transform:translateX(-50%) translateY(16px); } to { opacity:1; transform:translateX(-50%) translateY(0); } }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        input[type="date"]::-webkit-calendar-picker-indicator,
        input[type="time"]::-webkit-calendar-picker-indicator { filter: invert(0.7) sepia(1) hue-rotate(180deg); cursor: pointer; }
        select option { background: #0e1e38; color: #e8f4ff; }
        ::-webkit-scrollbar { height: 6px; width: 6px; }
        ::-webkit-scrollbar-thumb { background: rgba(100,160,255,0.3); border-radius: 3px; }
      `}</style>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#5a88bb", marginBottom: 6 }}>{label}</label>
      {children}
    </div>
  );
}

const inputStyle = {
  width: "100%", background: "rgba(255,255,255,0.06)",
  border: "1px solid rgba(100,160,255,0.2)", borderRadius: 9,
  color: "#e8f4ff", fontSize: 14, padding: "9px 12px",
  outline: "none", boxSizing: "border-box",
};

const tdStyle = {
  padding: "11px 14px", textAlign: "right", verticalAlign: "middle", color: "#c8dff5", fontSize: 14,
};
